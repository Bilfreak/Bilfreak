class BoughtTogether extends HTMLElement {
    constructor() {
        super();
        this.cacheDOMElements();
        this.addEventListeners();
        this.observeMainPriceChanges();
    }

    cacheDOMElements() {
        this.mainPrice = this.getMainPrice();
        this.mainForm = this.getMainForm();
        this.totalPriceElement = this.querySelector(".summary .price--final");
        this.priceTemplate = this.querySelector('template[data-id="price"]').innerHTML;
        this.samplePrice = this.getSamplePrice();
        this.decimalsSeparator = this.getPriceDecimalSeparator();
        this.itemsInput = this.querySelector('input[name="items[0][id]"]');
    }

    addEventListeners() {
        this.addEventListener("change", this.updateTotal.bind(this));
        if (this.mainForm) {
            this.mainForm.addEventListener("change", this.updateMainProductId.bind(this));
        }
    }

    observeMainPriceChanges() {
        if (this.mainPrice) {
            this.mainPriceMutation = new MutationObserver(() => {
                this.updateTotal();
                if (this.isMainSoldout()) {
                    this.itemsInput.setAttribute("disabled", true);
                } else {
                    this.itemsInput.removeAttribute("disabled");
                }
            });
            this.mainPriceMutation.observe(this.mainPrice.closest('[data-updatable="true"]'), {
                childList: true,
                subtree: true
            });
        }
    }

    updateMainProductId() {
        const variantId = this.mainForm.querySelector('input[name="id"]').value;
        this.itemsInput.value = variantId;
    }

    collectTotal() {
        let itemsTotal = this.isMainSoldout() ? 0 : parseInt(this.mainPrice?.dataset.amount.replace(/\D/g, ""));
        this.querySelectorAll('[type="checkbox"]:checked ~ .item-link .price--final').forEach(el => {
            itemsTotal += parseInt(el.dataset.amount.replace(/\D/g, ""));
        });
        return itemsTotal;
    }

    updateTotal() {
        requestAnimationFrame(() => {
            const total = this.collectTotal().toString();
            const [int, dec] = this.samplePrice.split(this.decimalsSeparator);
            this.totalPriceElement.outerHTML = this.priceTemplate
                .replaceAll(int, total.slice(0, total.length - dec.length))
                .replaceAll(dec, total.slice(-dec.length));
        });
    }

    getMainPrice() {
        return document.querySelector(".product-section .price--final");
    }

    getMainForm() {
        return document.querySelector(".product-section product-form");
    }

    isMainSoldout() {
        return !!this.mainPrice.closest(".price--sold-out");
    }

    getSamplePrice() {
        return this.querySelector('template[data-id="price"]')?.dataset.priceSample;
    }

    getPriceDecimalSeparator() {
        return this.samplePrice.indexOf(",") !== -1 ? "," : ".";
    }
}

customElements.define("bought-together", BoughtTogether);
