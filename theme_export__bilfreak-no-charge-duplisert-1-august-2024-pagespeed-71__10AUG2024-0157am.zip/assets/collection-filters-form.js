{{ 'template-collection.aio.min.css' | asset_url | stylesheet_tag }}
{{ 'component-price.aio.min.css' | asset_url | stylesheet_tag }}
{{ 'component-text-expandable.aio.min.css' | asset_url | stylesheet_tag }}

<div class="section-inner dynamic-page-width">
    {%- liquid
        assign asideLeft = ''
        assign asideRight = ''
        assign main = ''

        for block in section.blocks
            assign position = block.settings.position | split: '-' | first
            if position == 'left' or position == 'right'
                capture html
                    case block.type
                        when 'custom_liquid'
                            render 'collection__block--custom_liquid', block: block, blockOrder: forloop.index
                        when 'filters'
                            render 'collection__block--filters', block: block, blockOrder: forloop.index
                    endcase
                endcapture
            endif

            case position
                when 'left'
                    assign asideLeft = asideLeft | append: html | strip
                when 'right'
                    assign asideRight = asideRight | append: html | strip
            endcase
        endfor

        assign hasSideColumn = false
        if asideLeft.size > 0 or asideRight.size > 0
            assign hasSideColumn = true
        endif

        for block in section.blocks
            assign position = block.settings.position | split: '-' | first
            unless position == 'left' or position == 'right'
                capture html
                    case block.type
                        when '@app'
                            render 'collection__block--app', block: block, blockOrder: forloop.index
                        when 'custom_liquid'
                            render 'collection__block--custom_liquid', block: block, blockOrder: forloop.index
                        when 'description'
                            render 'collection__block--description', block: block, blockOrder: forloop.index
                        when 'featured'
                            render 'collection__block--featured', block: block, blockOrder: forloop.index, has_side_column: hasSideColumn
                        when 'filters'
                            render 'collection__block--filters', block: block, blockOrder: forloop.index
                        when 'image'
                            render 'collection__block--image', block: block, blockOrder: forloop.index
                        when 'products'
                            render 'collection__block--products', block: block, blockOrder: forloop.index, has_side_column: hasSideColumn
                        when 'title'
                            render 'collection__block--title', block: block, blockOrder: forloop.index
                    endcase
                endcapture

                assign main = main | append: html | strip
            endunless
        endfor
    -%}
    <div id="CollectionInfo-{{ section.id }}" class="collection__info">
        <div class="collection__info-aside collection__info-aside--left">{{ asideLeft }}</div>
        <div class="collection__info-main">{{ main }}</div>
        <div class="collection__info-aside collection__info-aside--right">{{ asideRight }}</div>
    </div>
</div>

<script src="{{ 'text-expandable.aio.min.js' | asset_url }}" defer="defer"></script>
<script src="{{ 'range-slider.aio.min.js' | asset_url }}" defer="defer"></script>
<script src="{{ 'collection-filters-form.aio.min.js' | asset_url }}" defer="defer"></script>
<script src="{{ 'collection-mode.js' | asset_url }}" defer="defer"></script>
<script src="{{ 'collection-pagination.aio.min.js' | asset_url }}" defer="defer"></script>
<link
    rel="preload"
    href="{{ 'component-listing-grid.aio.min.css' | asset_url }}"
    as="style"
    onload="this.onload=null;this.rel='stylesheet'"
>
<link
    rel="preload"
    href="{{ 'component-loading-overlay.aio.min.css' | asset_url }}"
    as="style"
    onload="this.onload=null;this.rel='stylesheet'"
>

<noscript>{{ 'component-listing-grid.css' | asset_url | stylesheet_tag }}</noscript>
<noscript>{{ 'component-loading-overlay.css' | asset_url | stylesheet_tag }}</noscript>

{% schema %}
{
  "name": "t:sections.main-collection.name",
  "class": "spaced-section collection-grid-section",
  "tag": "section",
  "blocks": [
    {
      "type": "@app"
    },
{
    "type": "custom_liquid",
    "name": "t:sections.custom-liquid.name",
    "settings": [
        {
          "type": "inline_richtext",
          "id": "title",
          "label": "t:sections.custom-liquid.settings.title.label"
        },
        {
            "type": "liquid",
            "id": "custom_liquid",
            "label": "t:sections.custom-liquid.settings.custom_liquid.label"
        },
        {
            "type": "select",
            "id": "position",
            "label": "t:sections.main-collection.blocks.all.settings.position.label",
            "info": "t:sections.main-collection.blocks.all.settings.position.info",
            "options": [
                {
                    "value": "left",
                    "label": "t:sections.main-collection.blocks.all.settings.position.options.left"
                },
                {
                    "value": "main",
                    "label": "t:sections.main-collection.blocks.all.settings.position.options.main"
                },
                {
                    "value": "right",
                    "label": "t:sections.main-collection.blocks.all.settings.position.options.right"
                }
            ],
            "default": "main"
        }
    ]
}
,
{
    "type": "description",
    "name": "t:sections.main-collection.blocks.description.name",
    "limit": 1,
    "settings": [
        {
            "type": "checkbox",
            "id": "is_collapsed",
            "default": true,
            "label": "t:sections.main-collection.blocks.description.settings.is_collapsed.label"
        },
        {
            "type": "range",
            "id": "initial_lines",
            "min": 1,
            "max": 20,
            "step": 1,
            "default": 5,
            "label": "t:sections.main-collection.blocks.description.settings.initial_lines.label"
        }
    ]
}
,
{
    "type": "featured",
    "name": "t:sections.main-collection.blocks.featured.name",
    "limit": 1,
    "settings": [
        {
            "type": "inline_richtext",
            "id": "heading",
            "label": "t:sections.main-collection.blocks.featured.settings.heading.label",
            "default": "Special Offers"
        },
        {
            "type": "product_list",
            "id": "source",
            "limit": 8,
            "label": "t:sections.all.promote_source.label",
            "info": "t:sections.all.promote_source.info"
        },
        {
            "type": "range",
            "id": "products_per_page",
            "min": 1,
            "max": 8,
            "step": 1,
            "default": 4,
            "label": "t:sections.main-collection.blocks.featured.settings.products_per_page.label"
        },
        {
            "type": "range",
            "id": "columns",
            "min": 1,
            "max": 8,
            "step": 1,
            "default": 4,
            "label": "t:sections.main-collection.blocks.featured.settings.columns.label"
        },
        {
            "type": "checkbox",
            "id": "is_random",
            "default": true,
            "label": "t:sections.all.promote_random.label"
        },
        {
            "type": "checkbox",
            "id": "is_preload",
            "default": false,
            "label": "t:sections.all.preload_images.label"
        },
        {
            "type": "header",
            "content": "t:sections.all.product-card.header"
        },
        {
            "type": "select",
            "id": "badge_size",
            "label": "t:sections.all.product-card.badge_size.label",
            "options": [
                {
                    "value": "xs",
                    "label": "t:sections.all.product-card.badge_size.options__1.label"
                },
                {
                    "value": "sm",
                    "label": "t:sections.all.product-card.badge_size.options__2.label"
                },
                {
                    "value": "md",
                    "label": "t:sections.all.product-card.badge_size.options__3.label"
                },
                {
                    "value": "lg",
                    "label": "t:sections.all.product-card.badge_size.options__4.label"
                }
            ],
            "default": "sm"
        },
        {
            "type": "select",
            "id": "image_ratio",
            "label": "t:sections.all.product-card.image_ratio.label",
            "options": [
                {
                    "value": "settings|product_card_image_ratio",
                    "label": "t:sections.all.product-card.image_ratio.options.default"
                },
                {
                    "value": "native",
                    "label": "t:sections.all.product-card.image_ratio.options.native"
                },
                {
                    "value": "1",
                    "label": "t:sections.all.product-card.image_ratio.options.1_by_1"
                },
                {
                    "value": "5/4",
                    "label": "t:sections.all.product-card.image_ratio.options.4_by_5"
                }
            ],
            "default": "settings|product_card_image_ratio"
        },
        {
            "type": "checkbox",
            "id": "show_to_cart_button",
            "default": true,
            "label": "t:sections.all.product-card.show_to_cart_button.label"
        },
        {
            "type": "checkbox",
            "id": "animation_on_reveal",
            "label": "t:sections.all.settings.animation_on_reveal.label",
            "default": true
        },
        {
            "type": "header",
            "content": "t:sections.main-collection.blocks.featured.settings.cover.header"
        },
        {
            "type": "color",
            "id": "cover_text_color",
            "label": "t:sections.main-collection.blocks.featured.settings.cover_text_color.label",
            "default": "#ffffff"
        },
        {
            "type": "color",
            "id": "cover_background",
            "label": "t:sections.main-collection.blocks.featured.settings.cover_background.label",
            "default": "#1c73f5"
        },
        {
            "type": "image_picker",
            "id": "cover_image",
            "label": "t:sections.main-collection.blocks.featured.settings.cover_image.label"
        }
    ]
}
,
{
    "type": "image",
    "name": "t:sections.main-collection.blocks.image.name",
    "limit": 1,
    "settings": [
        {
            "type": "image_picker",
            "id": "image",
            "label": "t:sections.main-collection.blocks.image.settings.image.label",
            "info": "t:sections.main-collection.blocks.image.settings.image.info"
        },
        {
            "type": "select",
            "id": "ratio",
            "label": "t:sections.all.product-card.image_ratio.label",
            "options": [
                {
                    "value": "native",
                    "label": "t:sections.all.product-card.image_ratio.options.native"
                },
                {
                    "value": "9/16",
                    "label": "t:sections.all.product-card.image_ratio.options.16_by_9"
                },
                {
                    "value": "1/2",
                    "label": "t:sections.all.product-card.image_ratio.options.2_by_1"
                },
                {
                    "value": "1/3",
                    "label": "t:sections.all.product-card.image_ratio.options.3_by_1"
                }
            ],
            "default": "1/3"
        }
    ]
}
,
{
    "type": "filters",
    "name": "t:sections.main-collection.blocks.filters.name",
    "limit": 1,
    "settings": [
        {
            "type": "paragraph",
            "content": "t:sections.main-collection.blocks.filters.settings.subtitle"
        },
        {
            "type": "select",
            "id": "position",
            "label": "t:sections.main-collection.blocks.all.settings.position.label",
            "info": "t:sections.main-collection.blocks.all.settings.position.info",
            "options": [
                {
                    "value": "left",
                    "label": "t:sections.main-collection.blocks.all.settings.position.options.left"
                },
                {
                    "value": "left-open",
                    "label": "t:sections.main-collection.blocks.all.settings.position.options.left_open"
                },
                {
                    "value": "main",
                    "label": "t:sections.main-collection.blocks.all.settings.position.options.main"
                },
                {
                    "value": "right",
                    "label": "t:sections.main-collection.blocks.all.settings.position.options.right"
                },
                {
                    "value": "right-open",
                    "label": "t:sections.main-collection.blocks.all.settings.position.options.right_open"
                }
            ],
            "default": "left-open"
        },
        {
            "type": "checkbox",
            "id": "show_colors_as_swatches",
            "label": "t:sections.main-collection.blocks.filters.settings.show_colors_as_swatches.label",
            "info": "t:sections.main-collection.blocks.filters.settings.show_colors_as_swatches.info",
            "default": true
        },
        {
            "type": "checkbox",
            "id": "show_color_swatch_labels",
            "label": "t:sections.main-collection.blocks.filters.settings.show_color_swatch_labels.label",
            "default": true
        },
        {
            "type": "checkbox",
            "id": "animation_on_reveal",
            "label": "t:sections.all.settings.animation_on_reveal.label",
            "default": false
        }
    ]
}
,
{
    "type": "products",
    "name": "t:sections.main-collection.blocks.products.name",
    "limit": 1,
    "settings": [
        {
            "type": "checkbox",
            "id": "show_sorting",
            "default": true,
            "label": "t:sections.main-collection.blocks.products.settings.show_sorting.label"
        },
        {
            "type": "checkbox",
            "id": "show_mode",
            "default": true,
            "label": "t:sections.main-collection.blocks.products.settings.show_mode.label"
        },
        {
            "type": "select",
            "id": "mode",
            "label": "t:sections.main-collection.blocks.products.settings.mode.label",
            "options": [
                {
                    "value": "grid",
                    "label": "t:sections.main-collection.blocks.products.settings.mode.options.grid"
                },
                {
                    "value": "list",
                    "label": "t:sections.main-collection.blocks.products.settings.mode.options.list"
                }
            ],
            "default": "grid"
        },
        {
            "type": "range",
            "id": "per_page",
            "min": 4,
            "max": 50,
            "step": 1,
            "default": 12,
            "label": "t:sections.main-collection.blocks.products.settings.per_page.label"
        },
        {
            "type": "range",
            "id": "columns",
            "label": "t:sections.main-collection.blocks.products.settings.columns.label",
            "info": "t:sections.main-collection.blocks.products.settings.columns.info",
            "min": 2,
            "max": 6,
            "step": 1,
            "default": 4
        },
        {
            "type": "checkbox",
            "id": "is_preload",
            "default": false,
            "label": "t:sections.all.preload_images.label"
        },
        {
            "type": "select",
            "id": "pagination_type",
            "label": "t:sections.main-list-collections.settings.pagination_type.label",
            "options": [
                {
                  "value": "pagination_list",
                  "label": "t:sections.main-list-collections.settings.pagination_type.options.pagination_list"
                },
                {
                  "value": "infinity_scroll",
                  "label": "t:sections.main-list-collections.settings.pagination_type.options.infinity_scroll"
                },
                {
                    "value": "load_more_button",
                    "label": "t:sections.main-list-collections.settings.pagination_type.options.load_more_button"
                }
            ],
            "default": "pagination_list"
        },
        {
            "type": "header",
            "content": "t:sections.all.product-card.header"
        },
        {
            "type": "select",
            "id": "badge_size",
            "label": "t:sections.all.product-card.badge_size.label",
            "options": [
                {
                    "value": "xs",
                    "label": "t:sections.all.product-card.badge_size.options__1.label"
                },
                {
                    "value": "sm",
                    "label": "t:sections.all.product-card.badge_size.options__2.label"
                },
                {
                    "value": "md",
                    "label": "t:sections.all.product-card.badge_size.options__3.label"
                },
                {
                    "value": "lg",
                    "label": "t:sections.all.product-card.badge_size.options__4.label"
                }
            ],
            "default": "sm"
        },
        {
            "type": "select",
            "id": "image_ratio",
            "label": "t:sections.all.product-card.image_ratio.label",
            "options": [
                {
                    "value": "settings|product_card_image_ratio",
                    "label": "t:sections.all.product-card.image_ratio.options.default"
                },
                {
                    "value": "native",
                    "label": "t:sections.all.product-card.image_ratio.options.native"
                },
                {
                    "value": "1",
                    "label": "t:sections.all.product-card.image_ratio.options.1_by_1"
                },
                {
                    "value": "5/4",
                    "label": "t:sections.all.product-card.image_ratio.options.4_by_5"
                }
            ],
            "default": "settings|product_card_image_ratio"
        },
        {
            "type": "checkbox",
            "id": "show_description",
            "default": false,
            "label": "t:sections.all.product-card.show_description.label"
        },
        {
            "type": "checkbox",
            "id": "show_swatch_options_color",
            "default": false,
            "label": "t:sections.all.product-card.show_swatch_options_color.label"
        },
        {
            "type": "checkbox",
            "id": "show_to_cart_button",
            "default": true,
            "label": "t:sections.all.product-card.show_to_cart_button.label"
        },
        {
            "type": "checkbox",
            "id": "animation_on_reveal",
            "label": "t:sections.all.settings.animation_on_reveal.label",
            "default": true
        }
    ]
}
,
{
      "type": "title",
      "name": "t:sections.main-collection.blocks.title.name",
      "limit": 1,
      "settings": [
            {
                  "type": "checkbox",
                  "id": "animation_on_reveal",
                  "label": "t:sections.all.settings.animation_on_reveal.label",
                  "default": true
            }
      ]
}

  ]
}
{% endschema %}

class CollectionFiltersForm extends HTMLElement {
    constructor() {
        super();
        this.filterData = [];
        this.onActiveFilterClick = this.onActiveFilterClick.bind(this);
        this.form = this.querySelector("form");

        this.debouncedOnSubmit = debounce((event) => {
            this.onSubmitHandler(event);
        }, 500);

        this.form.addEventListener("input", this.debouncedOnSubmit.bind(this));
        this.form.addEventListener(
            "changepage",
            this.onSubmitHandler.bind(this)
        );
        this.bindOuterControlEvnets();
        this.bindActiveFacetButtonEvents();

        if (!window.filtersEvenetOnHistoryChangeInited) {
            window.addEventListener(
                "popstate",
                this.onHistoryChange.bind(this)
            );
            window.filtersEvenetOnHistoryChangeInited = true;
        }

        // Ugly but it works. Fix for button-like facet when it is near the right side.
        if (this.classList.contains("facets__type-buttons"))
            this.querySelectorAll(".facets__disclosure").forEach((details) => {
                details.addEventListener("toggle", () => {
                    const list = details.querySelector(".facets__display");
                    const dX = details.getBoundingClientRect().x;
                    const lW = list ? list.getBoundingClientRect().width : 0;

                    if (list) {
                        if (window.innerWidth < dX + lW) {
                            list.style.left = "auto";
                            list.style.right = "-.5rem";
                        } else {
                            list.style.left = "";
                            list.style.right = "";
                        }
                    }
                });
            });
    }

    getCollectionEl() {
        return document
            .getElementById("CollectionProducts")
            .querySelector(".main-collection");
    }

    onSubmitHandler(event) {
        event.preventDefault();

        const formData = new FormData(this.form);
        const searchParams = new URLSearchParams(formData).toString();
        const revealItems = document.querySelectorAll(".reveal-slide-in");

        // disable on-scroll reveal items animation
        revealItems.length &&
            revealItems.forEach((item) =>
                item.classList.remove("reveal-ready")
            );
        this.renderPage(searchParams, event);
    }

    onActiveFilterClick(event) {
        event.preventDefault();
        this.toggleActiveFacets();
        this.renderPage(
            new URL(event.currentTarget.href).searchParams.toString()
        );
    }

    onHistoryChange(event) {
        const searchParams = event.state?.searchParams || "";
        this.renderPage(searchParams, null, false);
    }

    toggleActiveFacets(disable = true) {
        document.querySelectorAll(".js-facet-remove").forEach((element) => {
            element.classList.toggle("disabled", disable);
        });
    }

    renderPage(searchParams, event, updateURLHash = true) {
        const sections = this.getSections();
        const viewMode = new URL(window.location).searchParams.get("view");

        if (viewMode && searchParams.indexOf("view=") == -1) {
            searchParams = `view=${viewMode}&${searchParams}`.trim("&");
        }

        this.showLoading();
        sections.forEach((section) => {
            const url = `${window.location.pathname}?section_id=${section.section}&${searchParams}`;
            const filterDataUrl = (element) => element.url === url;

            this.filterData.some(filterDataUrl)
                ? this.renderSectionFromCache(filterDataUrl, section, event)
                : this.renderSectionFromFetch(url, section, event);
        });

        if (updateURLHash) this.updateURLHash(searchParams);
    }

    renderSectionFromFetch(url, section, event) {
        fetch(url)
            .then((response) => response.text())
            .then((responseText) => {
                const html = responseText;
                this.filterData = [...this.filterData, { html, url }];
                this.renderFilters(html, event);
                this.renderProductGrid(html);
            });
    }

    renderSectionFromCache(filterDataUrl, section, event) {
        const html = this.filterData.find(filterDataUrl).html;
        this.renderFilters(html, event);
        this.renderProductGrid(html);
    }

    async renderProductGrid(html) {
        const innerHTML = new DOMParser()
            .parseFromString(html, "text/html")
            .getElementById("CollectionProducts").innerHTML;
        const revealItems = document.querySelectorAll(".reveal-slide-in");

        document.getElementById("CollectionProducts").innerHTML = innerHTML;
        document
            .getElementById("CollectionProducts")
            .dispatchEvent(
                new CustomEvent("renderProductGrid", { bubbles: true })
            );
        if (revealItems.length) {
            await onReveal(revealItems);
            await updateItemZIndex(revealItems);
        }
    }

    renderFilters(html, event) {
        const parsedHTML = new DOMParser().parseFromString(html, "text/html");

        const facetDetailsElements = parsedHTML.querySelectorAll(
            "#CollectionFiltersForm .js-filter, #CollectionFiltersFormMobile .js-filter"
        );
        const matchesIndex = (element) =>
            element.dataset.index ===
            event?.target.closest(".js-filter")?.dataset.index;
        const facetsToRender = Array.from(facetDetailsElements).filter(
            (element) => !matchesIndex(element)
        );
        const countsToRender =
            Array.from(facetDetailsElements).find(matchesIndex);

        facetsToRender.forEach((element) => {
            document.querySelector(
                `.js-filter[data-index="${element.dataset.index}"]`
            ).innerHTML = element.innerHTML;
        });

        this.renderActiveFacets(parsedHTML);
        this.renderMobileElements(parsedHTML);

        if (countsToRender)
            this.renderCounts(
                countsToRender,
                event.target.closest(".js-filter")
            );
    }

    renderActiveFacets(html) {
        const activeFacetElementSelectors = [
            ".active-facets-mobile",
            ".active-facets-desktop",
        ];

        activeFacetElementSelectors.forEach((selector) => {
            const activeFacetsElement = html.querySelector(selector);
            if (!activeFacetsElement) return;
            document.querySelector(selector).innerHTML =
                activeFacetsElement.innerHTML;
        });

        this.bindActiveFacetButtonEvents();
        this.toggleActiveFacets(false);
    }

    renderMobileElements(html) {
        const mobileElementSelectors = [
            ".mobile-facets__open",
            ".mobile-facets__count",
        ];

        mobileElementSelectors.forEach((selector) => {
            const newElement = html.querySelector(selector);

            if (newElement) {
                document.querySelector(selector).innerHTML =
                    newElement.innerHTML;
            }
        });

        document
            .getElementById("CollectionFiltersFormMobile")
            ?.closest("menu-drawer")
            .bindEvents();
    }

    renderCounts(source, target) {
        const countElementSelectors = [".count-bubble", ".facets__selected"];
        countElementSelectors.forEach((selector) => {
            const targetElement = target.querySelector(selector);
            const sourceElement = source.querySelector(selector);

            if (sourceElement && targetElement) {
                target.querySelector(selector).outerHTML =
                    source.querySelector(selector).outerHTML;
            }
        });
    }

    bindActiveFacetButtonEvents() {
        document.querySelectorAll(".js-facet-remove").forEach((element) => {
            element.addEventListener("click", this.onActiveFilterClick, {
                once: true,
            });
        });
    }

    bindOuterControlEvnets() {
        document.body.addEventListener("input", (event) => {
            const id = this.form.getAttribute("id");
            if (id && event.target.getAttribute("form") == id) {
                this.debouncedOnSubmit(event);
            }
        });
    }

    updateURLHash(searchParams) {
        history.pushState(
            { searchParams },
            "",
            `${window.location.pathname}${
                searchParams && "?".concat(searchParams)
            }`
        );
    }

    showLoading() {
        const collection = this.getCollectionEl();

        if (!collection.querySelector(".loading-overlay"))
            collection.prepend(createFromTemplate("template-loading-overlay"));
        collection.classList.add("loading");
    }

    getSections() {
        return [
            {
                id: "main-collection-products",
                section: document.getElementById("main-collection-products")
                    .dataset.id,
            },
        ];
    }
}

customElements.define("collection-filters-form", CollectionFiltersForm);

class PriceRange extends HTMLElement {
    constructor() {
        super();
        this.querySelectorAll("input[type=number]").forEach((element) =>
            element.addEventListener("change", this.onRangeChange.bind(this))
        );

        this.setMinAndMaxValues();
        this.rangeSlider = this.querySelector("range-slider");
        if (this.rangeSlider) {
            this.rangeSlider.addEventListener(
                "input",
                this.onRangeSliderInput.bind(this)
            );
            this.addRangeSliderStyles();
            this.rangeSlider.insertAdjacentHTML("beforeend", "<div> </div>");
            this.onRangeSliderInput();
        }
    }

    addRangeSliderStyles() {
        if (document.getElementById("price-range-slider-styles")) return;

        const style = document.createElement("style");

        style.id = "price-range-slider-styles";
        style.innerHTML = `
        price-range range-slider {
          --thumb-width: .875rem;
          --thumb-border: 2px solid var(--color-background);
          --thumb-bg: ${getComputedStyle(this)
              .getPropertyValue("--color-base-accent-1-rgb")
              .replaceAll(",", " ")};
        }

        price-range range-slider div {
          background: rgba(var(--thumb-bg) / .9);
          border-radius: var(--track-border-radius);
          height: var(--track-height);
          position: absolute;
          top: calc(50% - var(--track-height) / 2);
        }
      `;

        document.head.append(style);
    }

    onRangeChange(event) {
        this.adjustToValidValues(event.currentTarget);
        this.setMinAndMaxValues();
        this.updateRangeSlider();
    }

    updateRangeSlider() {
        const inputs = this.querySelectorAll("input[type=number]");
        const minInput = inputs[0];
        const maxInput = inputs[1];
        const range = this.querySelector("range-slider");

        if (!range) return;

        range.value = [
            Math.floor(minInput.value || minInput.min),
            Math.ceil(maxInput.value || maxInput.max),
        ];
        this.onRangeSliderInput();
    }

    setMinAndMaxValues() {
        const inputs = this.querySelectorAll("input[type=number]");
        const minInput = inputs[0];
        const maxInput = inputs[1];
        if (maxInput.value) minInput.setAttribute("max", maxInput.value);
        if (minInput.value) maxInput.setAttribute("min", minInput.value);
        if (minInput.value === "") maxInput.setAttribute("min", 0);
        if (maxInput.value === "")
            minInput.setAttribute("max", maxInput.getAttribute("max"));
    }

    adjustToValidValues(input) {
        const value = Number(input.value);
        const min = Number(input.getAttribute("min"));
        const max = Number(input.getAttribute("max"));

        if (value < min) input.value = min;
        if (value > max) input.value = max;
    }

    onRangeSliderInput(event) {
        const range = this.rangeSlider;
        const min = Number(range.getAttribute("min"));
        const max = Number(range.getAttribute("max"));
        const value = range.value || range.getAttribute("value").split("-");
        const between = range.querySelector("div");

        between.style.left = `calc((${value[0]} - ${min})/ (${max} - ${min}) * 100%)`;
        between.style.width = `calc((${value[1]} - ${value[0]}) / (${max} - ${min}) * 100%)`;

        const inputs = this.querySelectorAll("input[type=number]");
        if (value[0] != min) inputs[0].value = value[0];
        else inputs[0].value = "";

        if (value[1] != max) inputs[1].value = value[1];
        else inputs[1].value = "";

        // event?.stopPropagation?.();
    }
}

customElements.define("price-range", PriceRange);
