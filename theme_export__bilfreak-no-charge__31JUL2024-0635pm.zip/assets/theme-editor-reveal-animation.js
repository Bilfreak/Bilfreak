document.addEventListener("shopify:block:select", async (event) => {
    const revealSection = new Set([event.target.closest(".reveal-slide-in")]);

    if (revealSection) await onReveal(revealSection);
});

document.addEventListener("shopify:section:select", async (event) => {
    const revealSection = new Set([
        event.target.querySelector(".reveal-slide-in"),
    ]);

    if (revealSection) await onReveal(revealSection);
});
