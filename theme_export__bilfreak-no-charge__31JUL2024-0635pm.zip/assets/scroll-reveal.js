const onReveal = (elements) => {
    let delay = 0.075;
    const options = {
        root: null,
        rootMargin: "0px 0px 150px 0px",
        threshold: 0.15,
    };
    const observer = new IntersectionObserver((entries, observer) => {
        entries.forEach((entry) => {
            if (!entry.isIntersecting) return;
            // activate reveal class
            entry.target.classList.add("reveal-ready");
            observer.unobserve(entry.target);
        });
    }, options);

    elements?.forEach((element, i) => {
        const childs = element ? element.querySelectorAll(".reveal-item") : "";
        if (!childs.length) return;

        let timeToDelay = 0;
        /*
         * observe element childs
         * sey element's childs delay
         */
        childs.forEach((child, i) => {
            observer.observe(child);
            // reduce animation delay when parent element inludes lots of items (e.g. - main-collection)
            if (timeToDelay > 1.5 && timeToDelay < 2) delay = 0.035;
            else if (timeToDelay > 2) delay = 0.015;

            timeToDelay = i * delay;
            child.style.animationDelay = timeToDelay + "s";
        });
    });
};

const updateItemZIndex = (elements) => {
    elements.forEach((element, i) => {
        const childs = element ? element.querySelectorAll(".reveal-item") : "";
        if (!childs.length) return;

        childs.forEach((child, i) => {
            child.addEventListener(
                "mouseenter",
                (e) => (child.style.zIndex = "10")
            );
            child.addEventListener("mouseleave", (e) =>
                child.style.removeProperty("z-index")
            );
        });
    });
};

async function init() {
    const elements = document.querySelectorAll(".reveal-slide-in");
    elements.length && (await onReveal(elements));
    // update item row z-index on Item hover
    elements.length && (await updateItemZIndex(elements));
}

init();
